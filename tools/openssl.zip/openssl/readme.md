###  generate origin private key

	genrsa -out private_key.pem 2048

### change private key to pkcs8

	pkcs8 -topk8 -inform PEM -in private_key.pem -outform PEM -nocrypt -out rsa_private_key.pem

### generate public key

	rsa -in rsa_private_key.pem -pubout -out rsa_public_key.pem